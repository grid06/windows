# Controller Application

## O'rnatish:
1. controller.exe va config.yaml fayllarni bir papkaga joylashtiring
2. config.yaml ni o'z ehtiyojingizga moslang
3. controller.exe ni ishga tushiring

## Talablar:
- Windows 10/11 yoki yuqori (64-bit)
- Internet aloqasi

## Xavfsizlik:
- Antivirus bloklashi mumkin (false positive)
- Firewall'da ruxsat bering

---
© 2026 Barcha huquqlar himoyalangan
